export { default } from './logo';
